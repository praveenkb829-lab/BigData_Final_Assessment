CREATE TABLE [dbo].[video_game_sales_clean] (

	[Rank] int NULL, 
	[Name] varchar(8000) NULL, 
	[Platform] varchar(8000) NULL, 
	[Year] int NULL, 
	[Genre] varchar(8000) NULL, 
	[Publisher] varchar(8000) NULL, 
	[NA_Sales] float NULL, 
	[EU_Sales] float NULL, 
	[JP_Sales] float NULL, 
	[Other_Sales] float NULL, 
	[Global_Sales] float NULL, 
	[Decade] int NULL
);